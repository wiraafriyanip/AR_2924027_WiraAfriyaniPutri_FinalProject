using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

/// <summary>
/// Spawns a configured content prefab only when the target reference image is tracked.
/// The prefab is parented to ARTrackedImage, so its pose follows the detected marker.
/// </summary>
[RequireComponent(typeof(ARTrackedImageManager))]
public class ARImagePrefabSpawner : MonoBehaviour
{
    [Header("Tracking")]
    [SerializeField] private ARTrackedImageManager imageManager;
    [SerializeField] private string targetReferenceName = "Marker_PinkBotanical";
    [SerializeField] private bool hideWhenTrackingIsLimited = true;
    [SerializeField] private bool writeTrackingLogs = true;

    [Header("AR Content Prefab")]
    [SerializeField] private GameObject contentPrefab;
    [SerializeField] private Vector3 localPosition = new Vector3(0f, 0.015f, 0f);
    [SerializeField] private Vector3 localEulerAngles = Vector3.zero;
    [SerializeField, Range(0.02f, 0.20f)] private float uniformScale = 0.07f;

    private readonly Dictionary<TrackableId, GameObject> spawnedContent =
        new Dictionary<TrackableId, GameObject>();

    private void Reset()
    {
        imageManager = GetComponent<ARTrackedImageManager>();
    }

    private void Awake()
    {
        if (imageManager == null)
            imageManager = GetComponent<ARTrackedImageManager>();
    }

    private void OnEnable()
    {
        if (imageManager != null)
            imageManager.trackablesChanged.AddListener(OnTrackablesChanged);
    }

    private void OnDisable()
    {
        if (imageManager != null)
            imageManager.trackablesChanged.RemoveListener(OnTrackablesChanged);
    }

    private void OnTrackablesChanged(ARTrackablesChangedEventArgs<ARTrackedImage> changes)
    {
        foreach (ARTrackedImage image in changes.added)
            UpdateTrackedImage(image);

        foreach (ARTrackedImage image in changes.updated)
            UpdateTrackedImage(image);

        foreach (var removed in changes.removed)
        {
            TrackableId id = removed.Key;
            if (spawnedContent.TryGetValue(id, out GameObject content))
            {
                if (content != null)
                    Destroy(content);
                spawnedContent.Remove(id);
                if (writeTrackingLogs)
                    Debug.Log("[AR Kelompok 4] Target image removed; content destroyed.");
            }
        }
    }

    private void UpdateTrackedImage(ARTrackedImage image)
    {
        if (image.referenceImage.name != targetReferenceName)
            return;

        if (!spawnedContent.TryGetValue(image.trackableId, out GameObject content) || content == null)
        {
            if (contentPrefab == null)
            {
                Debug.LogError("[AR Kelompok 4] Content Prefab belum diisi pada ARImagePrefabSpawner.");
                return;
            }

            content = Instantiate(contentPrefab, image.transform);
            content.name = "AR_PinkBotanicalGarden_Instance";
            content.transform.localPosition = localPosition;
            content.transform.localRotation = Quaternion.Euler(localEulerAngles);
            content.transform.localScale = Vector3.one * uniformScale;
            spawnedContent[image.trackableId] = content;

            if (writeTrackingLogs)
                Debug.Log("[AR Kelompok 4] Prefab Pink Botanical berhasil dibuat pada marker.");
        }

        bool isVisible = image.trackingState == TrackingState.Tracking ||
            (!hideWhenTrackingIsLimited && image.trackingState == TrackingState.Limited);

        content.SetActive(isVisible);
    }

    public void SetUniformScale(float newScale)
    {
        uniformScale = Mathf.Clamp(newScale, 0.02f, 0.20f);
        foreach (GameObject content in spawnedContent.Values)
        {
            if (content != null)
                content.transform.localScale = Vector3.one * uniformScale;
        }
    }
}
