using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

public class ARStatusOverlay : MonoBehaviour
{
    [SerializeField] private ARTrackedImageManager imageManager;
    [SerializeField] private bool showDiagnosticHud = true;

    private string status = "SEARCHING FOR MARKER";
    private int trackedImageCount = 0;

    private void Reset()
    {
        imageManager = GetComponent<ARTrackedImageManager>();
    }

    private void OnEnable()
    {
        // Resolve the manager on the same GameObject when the component is
        // added by the Editor builder before serialized references are applied.
        if (imageManager == null)
            imageManager = GetComponent<ARTrackedImageManager>();

        if (imageManager != null)
            imageManager.trackablesChanged.AddListener(OnImagesChanged);
        else
            Debug.LogWarning("[AR Kelompok 4] ARTrackedImageManager belum terpasang pada XR Origin.");
    }

    private void OnDisable()
    {
        if (imageManager != null)
            imageManager.trackablesChanged.RemoveListener(OnImagesChanged);
    }

    private void OnImagesChanged(ARTrackablesChangedEventArgs<ARTrackedImage> changes)
    {
        trackedImageCount = imageManager.trackables.count;

        foreach (ARTrackedImage image in changes.added)
            status = "MARKER DETECTED";

        foreach (ARTrackedImage image in changes.updated)
            status = image.trackingState == TrackingState.Tracking
                ? "TRACKING ACTIVE" : "TRACKING LIMITED";

        if (changes.removed.Count > 0)
            status = "SEARCHING FOR MARKER";
    }

    private void OnGUI()
    {
        if (!showDiagnosticHud)
            return;

        GUI.depth = -10;
        Rect panel = new Rect(16f, 16f, Mathf.Min(Screen.width - 32f, 430f), 86f);
        GUI.Box(panel, "");
        GUI.Label(new Rect(30f, 28f, panel.width - 24f, 24f),
            "PINK BOTANICAL AR  |  KELOMPOK 4");
        GUI.Label(new Rect(30f, 56f, panel.width - 24f, 24f),
            status + "   |   TRACKABLES: " + trackedImageCount);
    }
}
